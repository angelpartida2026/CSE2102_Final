module.exports = {
    testEnvironment: 'jsdom',
};

