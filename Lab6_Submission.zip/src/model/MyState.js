
class MyState {

    constructor() {
        var my_score = 0;
        var my_count = 0;
    }

};

export default MyState;