## How to Run the Project 
<br/>
1. Clone/Download the repository.
<br/>
3. Run `npm install` to install dependencies.
<br/>
5. Run `npm start` to launch the application. 
