import MyState from '../model/MyState';

var my_state = new MyState();


export default my_state;